//Comparator
public class QuadraticComparator {
	
	private double xval;
	
	public QuadraticComparator(){
		
	}		//im not really understanding what i am supposed to do with this?
			//I dont understand how i am supposed to use a comparator?
	
	public QuadraticComparator(double x){
		
		xval = x;
	}
}
