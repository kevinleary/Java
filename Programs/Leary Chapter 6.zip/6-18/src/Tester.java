/*

Kevin Leary
Period 2
Date: 11/12/14
Chapter: 6
Excercise: 18

*/
public class Tester {

	public static void main(String[] args) {
		
		DogtoHuman d = new DogtoHuman();
		
		System.out.print("The human age of the dog is " + d.convertToHumanAge(1));

	}

}
