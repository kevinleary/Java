
public class MyInitials {
		
		public String printK(int num)	//K declaration
		{
			String block[] = new String[9];
		     block[0]=("**     **");
			 block[1]=("**    ** ");
			 block[2]=("**   **  ");
			 block[3]=("**  **   ");
			 block[4]=("****     ");
			 block[5]=("** **    ");
			 block[6]=("**  **   ");
			 block[7]=("**    ** ");
			 block[8]=("**     **");
			
			return block[num];
			}
			
		
		public String printN(int num)
		{
			String block[] = new String[9];		//N declaration
			block[0]=("**       **");
			block[1]=("***      **");
			block[2]=("****     **");
			block[3]=("** **    **");
			block[4]=("**  **   **");
			block[5]=("**   **  **");
			block[6]=("**    ** **");
			block[7]=("**     ****");
			block[8]=("**      ***");
			return block[num];
		}
		
		public String printL(int num)
		{
			String block[] = new String[9];		//L declaration
			 block[0]=("**        ");
			 block[1]=("**        ");
			 block[2]=("**        ");
			 block[3]=("**        ");
			 block[4]=("**        ");
			 block[5]=("**        ");
			 block[6]=("**        ");
			 block[7]=("**        ");
			 block[8]=("********* ");
			 
			 return block[num];
			
		}
		
		public String printA(int num)	//A declaration
		{
			String block[] = new String[9];
		     block[0]=("  ****   ");
			 block[1]=(" **  **  ");
			 block[2]=("**    ** ");
			 block[3]=("**    ** ");
			 block[4]=("******** ");
			 block[5]=("**    ** ");
			 block[6]=("**    ** ");
			 block[7]=("**    ** ");
			 block[8]=("**    ** ");
			
			return block[num];
			}
		
		public String printB(int num)	//B declaration
		{
			String block[] = new String[9];
		     block[0]=("******   ");
			 block[1]=("**   **  ");
			 block[2]=("**    ** ");
			 block[3]=("**   **  ");
			 block[4]=("*****    ");
			 block[5]=("**   **  ");
			 block[6]=("**    ** ");
			 block[7]=("**   **  ");
			 block[8]=("*****    ");
			
			return block[num];
			}
		
	}
	
	
