
public class WelcomeFrench extends WelcomeMessage{

	
	public String getWelcomeMessage() {
		
		return "Bonjour!";
	}

}
