
public class WelcomeEnglish extends WelcomeMessage{

	
	public String getWelcomeMessage() {
		
		return "Hello!";
	}

}
