
public class WelcomeSpanish extends WelcomeMessage{

	
	public String getWelcomeMessage() {
		
		return "Hola!";
	}

}
