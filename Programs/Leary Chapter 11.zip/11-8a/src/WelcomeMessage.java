/*

Kevin Leary
Period 2
Date: 2/10/14
Chapter: 11
Excercise: 8a

*/


public abstract class WelcomeMessage {
	
	public abstract String getWelcomeMessage();		//abstract stub
}
