
public class WelcomeFrench implements WelcomeMessage{

	
	public String getWelcomeMessage() {
		
		return "Bonjour!";
	}

}
