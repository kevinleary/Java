
public class WelcomeEnglish implements WelcomeMessage{		//implements used instead of extends

	
	public String getWelcomeMessage() {
		
		return "Hello!";
	}

}
