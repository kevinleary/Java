/*

Kevin Leary
Period 2
Date: 2/10/14
Chapter: 11
Excercise: 8b

*/


public interface  WelcomeMessage {		//just changed to an interface
	
	public abstract String getWelcomeMessage();		//abstract stub
}
