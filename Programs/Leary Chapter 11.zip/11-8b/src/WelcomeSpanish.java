
public class WelcomeSpanish implements WelcomeMessage{

	
	public String getWelcomeMessage() {
		
		return "Hola!";
	}

}
