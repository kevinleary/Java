
public class Haiku extends Poem{

	@Override
	public int numLines() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSyllables(int k) {
		// TODO Auto-generated method stub
		return 0;
	}

}
