/*

Kevin Leary
Period 2
Date: 2/5/14
Chapter: 11
Excercise: 5

*/

public abstract class Poem {
	
	public abstract int numLines();
	
	public abstract int getSyllables(int k);
	
	public void printRhythm(){
		
		
	}
}
