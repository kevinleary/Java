
public class Poem{

		public void finishPoem(int n){
			
			switch (n)
			{
				case 1:
					System.out.println("buckle your shoe");
					break;
				case 2:
					System.out.println("buckle your shoe");
					break;
				case 3:
					System.out.println("shut the door");
					break;
				case 4:
					System.out.println("shut the door");
					break;
				case 5:
					System.out.println("pick up sticks");
					break;
				case 6: 
					System.out.println("pick up sticks");
					break;
				case 7: 
					System.out.println("lay them straight");
					break;
				case 8:
					System.out.println("lay them straight");
					break;
				case 9:
					System.out.println("a big fat hen");
					break;
				case 10:
					System.out.println("a big fat hen");
					break;		
				default: 
					System.out.println("you decided to quit");
					break;
				
			}
		}

}
